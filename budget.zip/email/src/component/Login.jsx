 import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import Register from "./Register";


 const Login = (props) => {
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    
    let nav = useNavigate()

    const handleChange = (e) => {
        if (e.target.name === 'email') {
            setEmail(e.target.value);
        } else if (e.target.name === 'password') {
            setPass(e.target.value);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault()
        let old=localStorage.getItem("Register")
        old=JSON.parse(old) ||[]
         const user = old.find(u => u.email === email && u.pass === pass);
            if(user){
                let profile = localStorage.setItem("profile",JSON.stringify(user))
                 nav('/View')
                 alert("login successfuly")
            }
            else{
                alert("give valid email and password")
                setTimeout(() => {
                    window.location.reload();
                },0);
            }
        }
    return (
        <div className="auth-form-container">
            <h2>Login</h2>
            <form className="login-form" onSubmit={handleSubmit}>
                <label htmlFor="email">Email</label>
                <input value={email} onChange={handleChange} type="email" placeholder="Enter your Email" id="email" name="email" />
                <label htmlFor="password">Password</label>
                <input value={pass} onChange={handleChange} type="password" placeholder="********" id="password" name="password" />
                <button type="submit" className="submit" >Log In</button>
            </form>
            <br />
            <button className="link-btn" onClick={()=>nav('/Register')}>Don't have an account? Register here.</button>
            <br/>
            <button className="link-btn" onClick={()=>nav('/')}>go back</button>
        </div>
    );
};
export default Login;