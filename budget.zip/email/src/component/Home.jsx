import React from 'react'
import { useNavigate } from 'react-router-dom'
import '../App.css'

export default function Home() {
  let nav = useNavigate()
  return (
    <div style={{backgroundColor:"rgba(0, 0, 0, 0.5)", height:"200px", width:"1000px"}} >
      <h1>Welcome</h1>
      <button className='back'  onClick={() => nav("/Login")}>Login</button>
      <br />
      <br />
    </div>
  )
}
