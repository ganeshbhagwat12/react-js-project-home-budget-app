import React, { useState } from 'react';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

export default function Localstorages() {
  const [date, setDate] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");

  let nav = useNavigate();

  console.log(date);
  console.log(category);
  console.log(description);
  console.log(amount);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("profile");
    console.log('Logout clicked');
    alert("logout sucessfully");
    nav('/');
  };

  const Handlesubmit = (e) => {
    let store_id = 1;

    let old = localStorage.getItem(`store`);
    old = JSON.parse(old) || [];

    if (old.length > 0) {
      store_id = old[old.length - 1].store_id + 1;
    }
    let user_details = JSON.parse(localStorage.getItem('profile'))
    let user_id = user_details.user_id

    let newuser = {
      store_id: store_id,
      user_id: user_id,
      date: date,
      category: category,
      description: description,
      amount: amount,
    };

    const alldata = [...old, newuser];
    localStorage.setItem(`store`, JSON.stringify(alldata));

    setTimeout(() => {
      window.location.reload();
    }, 0);

    nav('/Addit');
  };

  return (
    <div>
      <div className='sky'>
        <div className='ok'>
          <div>
            <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
              <div className="menu-icon" onClick={toggleSidebar}>
                &#9776;
              </div>
              <div className="brand">Your budget plan</div>
            </div>
          </div>
          <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
            <div className="sidebar-item" onClick={toggleSidebar}>
              <FaTimes className="icon" />
              Close
            </div>
            <div className="sidebar-item" onClick={() => nav('/Profile')}>
              <FaUser className="icon" />
              Add Profile
            </div>
            <div className="sidebar-item" onClick={() => nav('/Addit')}>
              <FaMoneyBill className="icon" />
              Add Expense
            </div>
            <div className="sidebar-item" onClick={() => nav('/Status')}>
              <FaSignal className="icon" />
              Status
            </div>
            <div className="sidebar-item" onClick={handleLogout}>
              <FaSignOutAlt className="icon" />
              Logout
            </div>
          </div>
        </div>
      </div>
      <div>
        <h1 style={{ backgroundColor: 'red', color: 'black' }}>Home budget app</h1>

        <h3 style={{ color: 'blue' }}>Home Expense</h3>
        <input
          style={{ fontSize: '35px' }}
          type="date"
          onChange={(e) => setDate(e.target.value)}
          name="date"
          placeholder="Enter date"
        />
        <br />
        <input
          style={{ fontSize: '35px' }}
          type="text"
          onChange={(e) => setCategory(e.target.value)}
          name="category"
          placeholder="Enter category"
        />
        <br />
        <input
          style={{ fontSize: '35px' }}
          type="text"
          onChange={(e) => setDescription(e.target.value)}
          name="discription"
          placeholder="Enter description"
        />
        <br />
        <input
          style={{ fontSize: '35px' }}
          type="number"
          onChange={(e) => setAmount(e.target.value)}
          name="amount"
          placeholder="Enter amount ₹"
        />
        <br />
        <button style={{ fontSize: '35px' }} onClick={Handlesubmit}>
          Insert
        </button>
      </div>
    </div>
  );
}
