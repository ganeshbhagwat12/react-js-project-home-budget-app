import React, { useState } from 'react';
import { json, useNavigate } from 'react-router-dom';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';


const Profile = () => {
  const storedData = JSON.parse(localStorage.getItem('profile')) || {
    name: '',
    phone: '',
    email: '',
    incomeSource: '',
    monthlyIncome: '',
  };
  const nave=useNavigate()
  const [userData, setUserData] = useState(storedData);
  const [isEditing, setEditing] = useState(false);
  const [editedUserData, setEditedUserData] = useState({ ...storedData });

  const handleEdit = () => {
    setEditing(true);
  };

  const handleSave = () => {
    setEditing(false);
    setUserData(editedUserData);
    localStorage.setItem('profile', JSON.stringify(editedUserData));
    let data = JSON.parse(localStorage.getItem('Register'))
    let index;
    let single = data.filter((item,ind)=>{
      if(item.user_id == storedData.user_id){
        index = ind
        return  item.user_id == storedData.user_id
      }
      return ""
    })

    single[0].incomeSource= editedUserData.incomeSource;
    single[0].monthlyIncome = editedUserData.monthlyIncome;
    console.log(single,87787878787)

    data.splice(index,1,...single)

    console.log(data,9999999)
    
    localStorage.setItem("Register",JSON.stringify(data))
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedUserData((prevUserData) => ({ ...prevUserData, [name]: value }));
  };
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  let nav = useNavigate();

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("profile");
    console.log('Logout clicked');
    alert("logout sucessfully");
    nav('/');
  };

  return (
    <div>
     <div  className='sky'>
    <div className='by'>
     <div>
    <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
      <div className="menu-icon" onClick={toggleSidebar}>
        &#9776;
       </div>
    <div className="brand">Your budget plan</div>
    </div>
   </div>
   </div>
  <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
    <div className="sidebar-item" onClick={toggleSidebar }>
     <FaTimes className="icon" />
      Close
    </div>
     <div className="sidebar-item" onClick={() => nav('/Profile')}>
       <FaUser className="icon" />
      Add Profile
    </div>
    <div className="sidebar-item" onClick={() => nav('/Addit')}>
      <FaMoneyBill className="icon" />
      Add Expense
    </div>
    <div className="sidebar-item" onClick={() => nav('/Status')}>
      <FaSignal className="icon" />
      Status
    </div>
    <div className="sidebar-item" onClick={handleLogout}>
      <FaSignOutAlt className="icon" />
      Logout
  </div>
 </div>
 </div>
 <div>
    <div className='prof'>
      <h2>User Profile</h2>
      {isEditing ? (
        <div>
        <div>
          <label>
            Name:
            <input type="text" name="name" value={editedUserData.name} onChange={handleChange}  className='star'/>
          </label>
          <br />
          <label>
            Phone Number:
            <input type="text" name="phone" value={editedUserData.phone} onChange={handleChange} className='star' />
          </label>
          <br />
          <label>
            Email:
            <input type="email" name="email" value={editedUserData.email} onChange={handleChange} className='star' />
          </label>
          <br />
          <label>
            Income Source:
            <input type="text" name="incomeSource" value={editedUserData.incomeSource} onChange={handleChange} className='star' />
          </label>
          <br />
          <label>
            monthly Income ₹:
            <input type="number" name="monthlyIncome" value={editedUserData.monthlyIncome} onChange={handleChange} className='star' />
          </label>
          <br />
          <button onClick={handleSave} className='hi' >Save</button>
          <br/>
          <button onClick={() => setEditing(false)} className='h'>Cancel</button>
        </div>
        </div>
      ) : (
        <div><img
        src="https://www.svgrepo.com/show/384674/account-avatar-profile-user-11.svg"
        alt="Profile Avatar"
        className="profile-avatar"
      />
          <p>Name: {userData.name}</p>
          <p>Phone Number: {userData.phone}</p>
          <p>Email: {userData.email}</p>
          <p>Income Source: {userData.incomeSource}</p>
          <p>monthly Income: {userData.monthlyIncome}</p>
          <button className="hi" onClick={handleEdit}>Edit</button>
          <br/>
          <button className="link-btn" onClick={()=>nave('/View')}>go back</button>
        </div>
      )}
    </div> 
    </div>
    </div>
  );
};

export default Profile;
