import React, { useState, useEffect } from 'react';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const Status = () => {
  const [storedExpensesData, setStoredExpensesData] = useState({
    name: '',
    monthlyIncome: 0,
  });
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [expenses, setExpenses] = useState(0);
  const [remainingBudget, setRemainingBudget] = useState(0);
  const nav = useNavigate();

  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem('profile')) || {
      name: '',
      monthlyIncome: 0,
      expenses: 0,
    };

    let storedExpensesData = JSON.parse(localStorage.getItem('store')) || [];
    let log_details = JSON.parse(localStorage.getItem('profile'));
    let log_id = log_details.user_id;

    let details = storedExpensesData.filter((item) => item.user_id === log_id);

    setStoredExpensesData(storedUserData);
    setExpenses(details.reduce((acc, expense) => acc + parseFloat(expense.amount), 0));
  }, []);

  useEffect(() => {
    // Calculate remainingBudget after expenses is updated
    setRemainingBudget(storedExpensesData.monthlyIncome - expenses);
  }, [expenses, storedExpensesData.monthlyIncome]);

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem('profile');
    console.log('Logout clicked');
    alert('Logout successfully');
    nav('/');
  };

  return (
    <div>
      <div className='buy'>
        <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
          <div className="menu-icon" onClick={toggleSidebar}>
            &#9776;
          </div>
          <div className="brand">Your budget plan</div>
        </div>
      </div>
      <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-item" onClick={toggleSidebar}>
          <FaTimes className="icon" />
          Close
        </div>
        <div className="sidebar-item" onClick={() => nav('/Profile')}>
          <FaUser className="icon" />
          Add Profile
        </div>
        <div className="sidebar-item" onClick={() => nav('/Addit')}>
          <FaMoneyBill className="icon" />
          Add Expense
        </div>
        <div className="sidebar-item" onClick={() => nav('/Status')}>
          <FaSignal className="icon" />
          Status
        </div>
        <div className="sidebar-item" onClick={handleLogout}>
          <FaSignOutAlt className="icon" />
          Logout
        </div>
      </div>
      <div className='status'>
        <h2>Status</h2>
        <img
          src="https://www.svgrepo.com/show/384674/account-avatar-profile-user-11.svg"
          alt="Profile Avatar"
          className="profile-avatar"
        />
        <p>User: {storedExpensesData.name}</p>
        <p>Monthly Income ₹: {storedExpensesData.monthlyIncome}</p>
        <p>Total Expenses ₹: {expenses}</p>
        <p>Remaining Budget ₹: {remainingBudget}</p>
        <button className="link-btn" onClick={() => nav('/View')}>go back</button>
      </div>
    </div>
  );
};

export default Status;
