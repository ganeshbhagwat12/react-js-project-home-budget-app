import React, { useState } from "react";
import logo from './logo.svg';
import './App.css';
import './Extension.css'

import Router from  "./component/Router"

function App() {
  const [currentForm, setCurrentForm] = useState('login');

  const toggleForm = (formName) => {
    setCurrentForm(formName);
  }
  return (
    
     <div className="App">
        <Router/>
        </div>
  );
}

export default App;

