import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';
import Button from '@mui/material/Button';

export default function Edit() {
  let { item } = useParams();
  let nav = useNavigate();

  const [user, setUser] = useState({});
  const [date, setDate] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [user_id, setUser_id] = useState();
  const [store_id, setStore_id] = useState();



  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("profile");
    console.log('Logout clicked');
    alert("logout sucessfully");
    nav('/');
  };

  const [index, setIndex] = useState();

  useEffect(() => {
    let data = JSON.parse(localStorage.getItem('store'));
    let single_data = data.filter((value, i) => {
      return value.store_id == item;
    });
    
    let ind = data.indexOf(...single_data)
    setIndex(ind)

    console.log(ind, 2323232323)

    console.log(single_data, 8888);
    // setUser(...single_data);
    setStore_id(single_data[0].store_id)
    setUser_id(single_data[0].user_id)
    setDate(single_data[0].date)
    setCategory(single_data[0].category)
    setDescription(single_data[0].description)
    setAmount(single_data[0].amount)


  }, []);

  // console.log(user, 99999);

  const Edit = () => {
    console.log(index,87878787)
    let data = JSON.parse(localStorage.getItem('store'));
    data.splice(index, 1, { store_id, user_id, date, category, description, amount });
    console.log(data);
    localStorage.setItem('store', JSON.stringify(data));
    nav('/Addit');
  };

  return (
    <div >
      <div className='sky'>
        <div className='ok'>
          <div>
            <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
              <div className="menu-icon" onClick={toggleSidebar}>
                &#9776;
              </div>
              <div className="brand">Your budget plan</div>
            </div>
          </div>
          <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
            <div className="sidebar-item" onClick={toggleSidebar}>
              <FaTimes className="icon" />
              Close
            </div>
            <div className="sidebar-item" onClick={() => nav('/Profile')}>
              <FaUser className="icon" />
              Add Profile
            </div>
            <div className="sidebar-item" onClick={() => nav('/Addit')}>
              <FaMoneyBill className="icon" />
              Add Expense
            </div>
            <div className="sidebar-item" onClick={() => nav('/Status')}>
              <FaSignal className="icon" />
              Status
            </div>
            <div className="sidebar-item" onClick={handleLogout}>
              <FaSignOutAlt className="icon" />
              Logout
            </div>
          </div>
        </div>
      </div>
      <h1 style={{ color: "red" }}>Home Budget</h1>
      <br />
      <input type="date"
        value={date}
        style={{ fontSize: '35px' }}
        onChange={(e) => setDate(e.target.value)}
        name="date"
        placeholder="Enter date"
      />
      <br />
      <br />
      <input type="text"
        value={category}
        style={{ fontSize: '35px' }}
        onChange={(e) => setCategory(e.target.value)}
        name="category"
        placeholder="enter category"
      />
      <br />
      <br />
      <input
        value={description}
        style={{ fontSize: '35px' }}
        type="text"
        onChange={(e) => setDescription(e.target.value)}
        name="description"
        placeholder="Enter description"
      />
      <br />
      <br />
      <input
        value={amount}
        style={{ fontSize: '35px' }}
        type="number"
        onChange={(e) => setAmount(e.target.value)}
        name="amount"
        placeholder="Enter amount ₹ "
      />
      <br />
      <br />
      <Button style={{ fontSize: "22px" }} onClick={Edit} variant="contained">
        Add Edit
      </Button>
    </div>
  );
}
