
import React, { useState, useEffect } from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';
import { FaBold } from 'react-icons/fa';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';


export default function Addit() {
  const [row, setRow] = useState([]);
  const currentUser = JSON.parse(localStorage.getItem('currentUser')) || {};
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  let nav = useNavigate();

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("profile");
    // localStorage.removeItem("userData");
    console.log('Logout clicked');
    alert("logout sucessfully");
    nav('/');
  };


  useEffect(() => {
    let userData = JSON.parse(localStorage.getItem('store')) || [];
    let log_details = JSON.parse(localStorage.getItem('profile'));
    let log_id = log_details.user_id;


    let details = userData.filter((item) => {
      return item.user_id == log_id
    })


    setRow(details || []);

  }, []);

  console.log(row);

  const [open, setOpen] = React.useState(false);
  const [deleteId, setDeleteId] = useState();

  const handleOpen = (store_id) => {
    setDeleteId(store_id);

    setOpen(true);
  };

  const handleClose = () => setOpen(false);

  const Delete = async () => {
    let newData = row.filter((item,index) => {
     return item.store_id!== deleteId;
    });
    setRow(newData);
    console.log(newData, 7777777)
    await localStorage.setItem('store', JSON.stringify(newData));
    await handleClose();
  };

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

  return (
    <>
      <div className='ok'>
        <div>
          <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
            <div className="menu-icon" onClick={toggleSidebar}>
              &#9776;
            </div>
            <div className="brand">Your budget plan</div>
          </div>
        </div>
        <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
          <div className="sidebar-item" onClick={toggleSidebar}>
            <FaTimes className="icon" />
            Close
          </div>
          <div className="sidebar-item" onClick={() => nav('/Profile')}>
            <FaUser className="icon" />
            Add Profile
          </div>
          <div className="sidebar-item" onClick={() => nav('/Addit')}>
            <FaMoneyBill className="icon" />
            Add Expense
          </div>
          <div className="sidebar-item" onClick={() => nav('/Status')}>
            <FaSignal className="icon" />
            Status
          </div>
          <div className="sidebar-item" onClick={handleLogout}>
            <FaSignOutAlt className="icon" />
            Logout
          </div>
        </div>
      </div>
      <div className="card-container" style={{ overflowY: 'auto', maxHeight: '80vh' }}>
        {row.map((rows, index) => {
          return (
            <div className='in' key={index}>
              <Card sx={{ width: 345, margin: "10px", height: 450 }}>
                <CardMedia
                  component="img"
                  alt="green iguana"
                  height="140"
                  image="https://www.shutterstock.com/image-photo/bank-interest-home-rate-housing-260nw-2280753907.jpg"
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div" color={"black"} fontWeight={"Bold"}>
                    Expense details
                  </Typography>
                  <Typography variant="body2" color="text.secondary" fontWeight={"Bold"} fontSize={"20px"} Color={"blue"} >
                    date: {rows.date}
                    <br />
                    Expense category:{rows.category}
                    <br />
                    description:{rows.description}
                    <br />
                    amount ₹:{rows.amount}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Link to={`/Eddit/${rows.store_id}`}>
                    <Button color="success" variant="contained">Edit</Button>
                  </Link>
                  <Button onClick={() => handleOpen(rows.store_id)} color="error" variant="contained">Delete</Button>
                </CardActions>
              </Card>
            </div>
          )
        })}
      </div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Text in a modal
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Are you sure you want to delete!!
          </Typography>
          <Button style={{ margin: "20px" }} onClick={Delete} color="success" variant="contained" size="small" >YES</Button>
          <Button onClick={handleClose} color="error" variant="contained" size="small" >NO</Button>
        </Box>
      </Modal>
      <div>
        <button className="b" onClick={() => nav('/Store')} style={{ color: "white" }}>Insert</button>
        <br />
        <button className="link-btn" onClick={() => nav('/View')}>go back</button>
      </div>
    </>
  );
}
