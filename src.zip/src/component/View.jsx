import React, { useState } from 'react';
import { FaUser, FaMoneyBill, FaSignal, FaSignOutAlt, FaTimes } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

export default function View() {
 
 const [isSidebarOpen, setSidebarOpen] = useState(false);
  let nav = useNavigate();

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem("profile");
    console.log('Logout clicked');
    alert("logout sucessfully");
    nav('/');
  };
  return (
    <div className='ok'>
      <div>
        <div className="navbar" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)", height: "100px", width: "300px" }}>
          <div className="menu-icon" onClick={toggleSidebar}>
            &#9776;
          </div>
          <div className="brand">Your budget plan</div>
        </div>
      </div>
      <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-item" onClick={toggleSidebar }>
          <FaTimes className="icon" />
          Close
        </div>
        <div className="sidebar-item" onClick={() => nav('/Profile')}>
          <FaUser className="icon" />
          Add Profile
        </div>
        <div className="sidebar-item" onClick={() => nav('/Addit')}>
          <FaMoneyBill className="icon" />
          Add Expense
        </div>
        <div className="sidebar-item" onClick={() => nav('/Status')}>
          <FaSignal className="icon" />
          Status
        </div>
        <div className="sidebar-item" onClick={handleLogout}>
          <FaSignOutAlt className="icon" />
          Logout
        </div>
      </div>
      <div className='content' style={{ fontWeight: "bold" }}>
        Welcome Home Budget app
      </div>
    </div>
  );
}
