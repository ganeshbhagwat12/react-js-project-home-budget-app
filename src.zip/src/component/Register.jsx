import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';

const Register = () => {
    let nav = useNavigate();
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');

    console.log(email);
    console.log(pass);
    console.log(name);
    console.log(phone);

    const handleSubmit = (e) => {
        e.preventDefault();

        const phonetest = /^[0-9]{10}$/;
        if (!phonetest.test(phone)) {
            alert('Invalid phone number. Please enter a 10-digit phone number.');
            return;
        }

    const password = /^[1-9A-Za-z@#]+$/;
    if (!password.test(pass)) {
        alert('Invalid password. Password must contain only 1 to 9, A to Z, a to z, @, and #.');
        return;
    }
        if (!name || !email || !pass || !phone) {
            alert('Please fill in all fields.');
            return;
        }

        let user_id = 1;
        let old = localStorage.getItem("Register");
        old = JSON.parse(old) || [];

        if (old) {
            if (old.length === 0 || old.length === null) {
                user_id = 1;
            } else {
                user_id = old[old.length - 1].user_id + 1;
            }
        }

        let newuser = {
            user_id : user_id,
            name: name,
            email: email,
            pass: pass,
            phone: phone
        };

        const alldata = [...old, newuser];
        localStorage.setItem("Register", JSON.stringify(alldata));
        alert("Registered");

        setTimeout(() => {
            window.location.reload();
        }, 0);

        nav('/Login');
    };

    return (
        <div className="auth-form-container">
            <h2>Register</h2>
            <form className="register-form" onSubmit={handleSubmit}>
                <label htmlFor="name">Full name</label>
                <input value={name} name="name" onChange={(e) => setName(e.target.value)} id="name" placeholder="full Name" />
                <label htmlFor="email">email</label>
                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="enter your Email" id="email" name="email" />
                <label htmlFor="password">password</label>
                <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="********" id="password" name="password" />
                <label htmlFor="phone">phoneNo</label>
                <input value={phone} onChange={(e) => setPhone(e.target.value)} type="phone" placeholder="enter your phoneNo" id="phone" name="phone" />
                <button type="submit" className="submit">Register</button>
            </form>
            <br />
        </div>
    );
};

export default Register;
