import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './Home'
import Login from './Login'
import Register from './Register'
import View from './View'
import Profile from './Profile'
 import Addit from './Addit'
 import Eddit from './Eddit'
 import Store from './Store'
 import Status from './Status'



export default function Router() {
    return (
        <BrowserRouter>
            <Routes>
                <Route exact path="/" element={<Home />} />
                <Route exact path="/Login" element={<Login />} />
                <Route exact path="/Register" element={<Register />} />
                <Route exact path="/View" element={<View/>} />
                <Route exact path="/Profile" element={<Profile/>} />
                <Route exact path="/Addit" element={<Addit/>} />
                <Route exact path="/Eddit/:item" element={<Eddit/>} />
                <Route exact path="/Store" element={<Store/>} /> 
                <Route exact path="/Status" element={<Status/>} />   
            </Routes>
        </BrowserRouter>
    )
}
